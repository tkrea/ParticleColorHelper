ParticleEditor Color Helper

---------------------------

This tool is still under development, so some readings may not always be perfectly accurate on their own.
For best results, always click the first RGB box (R value) before pressing F1.
This guarantees the script reads the correct color — tested and 100% safe.
⚠️ Windows may show a warning when running the EXE.
This is normal for unsigned tools.
In rare cases Windows Defender may delete it — this is a false positive.

How to Use

Extract the entire folder anywhere (Desktop, Documents, etc.).

Open ParticleColorHelper.exe.

Use:

F1 → Apply MAX RGB values

F4 → Apply MIN RGB values

Open the Settings tab to:

Change the UI theme

Enable/disable the Mini Dock

Change your profile picture

Credits

Made by: Sung Jinwoo𓄿
Discord: tk_rea